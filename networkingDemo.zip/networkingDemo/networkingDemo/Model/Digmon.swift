//
//  Digmon.swift
//  networkingDemo
//
//  Created by user on 24/11/2021.
//

import Foundation

struct Digmon: Codable {
    var name:String
    var img:String
    var level:String
}
